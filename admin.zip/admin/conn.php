<?php

$host = "localhost";
$user = "root";
$pass = "";
$dbname = "stalib";
$con = mysqli_connect($host, $user, $pass, $dbname);
?>