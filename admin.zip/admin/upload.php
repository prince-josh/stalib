<?php
include("conn.php");
?>
<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicon.png">
    <title>Upload - STAlib</title>
    <!-- Custom CSS -->
    <link href="assets/extra-libs/c3/c3.min.css" rel="stylesheet">
    <link href="assets/libs/chartist/dist/chartist.min.css" rel="stylesheet">
    <link href="assets/extra-libs/jvector/jquery-jvectormap-2.0.2.css" rel="stylesheet" />
    <!-- Custom CSS -->
    <link href="dist/css/style.min.css" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
</head>

<body>
    <!-- ============================================================== -->
    <!-- Preloader - style you can find in spinners.css -->
    <!-- ============================================================== -->
    <div class="preloader">
        <div class="lds-ripple">
            <div class="lds-pos"></div>
            <div class="lds-pos"></div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- Main wrapper - style you can find in pages.scss -->
    <!-- ============================================================== -->
    <div id="main-wrapper" data-theme="light" data-layout="vertical" data-navbarbg="skin6" data-sidebartype="full"
        data-sidebar-position="fixed" data-header-position="fixed" data-boxed-layout="full">
        <!-- ============================================================== -->
        <!-- Topbar header - style you can find in pages.scss -->
        <!-- ============================================================== -->
        <?php include "header.php" ?>
        <!-- ============================================================== -->
        <!-- End Topbar header -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <?php include "sidebar.php" ?>
        <!-- ============================================================== -->
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page wrapper  -->
        <!-- ============================================================== -->
        <div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-7 align-self-center">
                        <h3 class="page-title text-truncate text-dark font-weight-medium mb-1">
                            <?php
                            $date = date("H");
                            switch ($date) {
                                case $date < 12 :
                                    echo "Good Morning";
                                    break;
                                case $date >= 12 AND $date < 16:
                                    echo "Good Afternoon";
                                    break;
                                case $date >= 16 :
                                    echo "Good Evening";
                                    break;
                                default:
                                    # code...
                                    break;
                            }
                            ?>
                         Chiedoziem!</h3>
                        <div class="d-flex align-items-center">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb m-0 p-0">
                                    <li class="breadcrumb-item"><a href="index.html">Upload Material</a>
                                    </li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                    <!-- <div class="col-5 align-self-center">
                        <div class="customize-input float-right">
                            <select class="custom-select custom-select-set form-control bg-white border-0 custom-shadow custom-radius">
                                <option selected>Aug 19</option>
                                <option value="1">July 19</option>
                                <option value="2">Jun 19</option>
                            </select>
                        </div>
                    </div> -->
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                
                <!-- *************************************************************** -->
                <!-- Start Upload Material -->
                <!-- *************************************************************** -->
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="d-flex align-items-center mb-4">
                                    <h4 class="card-title">Upload Materials</h4>
                                    <div class="ml-auto">
                                        
                                    </div>
                                </div>
                                <form action="upload.php" method="post" enctype ="multipart/form-data">
                                    <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                        <label class="" for="name">Material Name</label>
                                            <input type="text" required name = "title" class="form-control" placeholder="Enter Material Name...">
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group">
                                        <label class="" for="code">Course Code</label>
                                            <input type="text" required name = "code" class="form-control" placeholder="Enter Course Code...">
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label class="" for="level">Select Level</label>
                                            <select class="custom-select" id="level" name = "level" required>
                                                <option selected>Select Level</option>
                                                <option value="100">100</option>
                                                <option value="200">200</option>
                                                <option value="300">300</option>
                                                <option value="400">400</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group">
                                        <label class="" for="code">Description (optional)</label>
                                            <textarea name="desc" id="" class="form-control" rows="5" placeholder="Give a short description about the material..."></textarea>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                    <label class="" for="level">Upload Material(PDF)</label>
                                    <div class="input-group">
                                        <!-- <div class="input-group-prepend">
                                            <span class="input-group-text">Upload Cover Page</span>
                                        </div> -->
                                        
                                        <div class="custom-file">
                                            <input required type="file" class="custom-file-input" id="material" name = "material">
                                            <label class="custom-file-label" for="material">Choose file</label>
                                        </div>
                                    </div>
                                    </div>

                                    <div class="col-md-12 mt-3">
                                    <label class="" for="level">Upload Cover Image(optional)</label>
                                    <div class="input-group">
                                        <!-- <div class="input-group-prepend">
                                            <span class="input-group-text">Upload Cover Page</span>
                                        </div> -->
                                        
                                        <div class="custom-file">
                                            <input type="file" class="custom-file-input" id="image" name = "dp">
                                            <label class="custom-file-label" for="image">Choose file</label>
                                        </div>
                                    </div>
                                    </div>
                                    <div class="col-md-12 mt-3 mx-auto">
                                        <div class="form-actions">
                                        <div class="text-right">
                                            <button type="submit" class="btn btn-info" name = "submit">Submit</button>
                                            <button type="reset" class="btn btn-dark">Reset</button>
                                        </div>
                                    </div>
                                    </div>
                                    </div><!--row end-->
                                </form>
                                <?php
                                if (isset($_POST['submit'])) {
                                    $title = mysqli_real_escape_string($con, htmlspecialchars($_POST['title']));
                                    $code = mysqli_real_escape_string($con, htmlspecialchars($_POST['code']));
                                    $level = mysqli_real_escape_string($con, htmlspecialchars($_POST['level']));
                                    $desc = mysqli_real_escape_string($con, htmlspecialchars($_POST["desc"]));
                                    $material = $_FILES['material']['name'];
                                    $tmp_material = $_FILES['material']['tmp_name'];
                                    $dp = $_FILES['dp']['name'];
                                    $tmp_dp = $_FILES['dp']['tmp_name'];
                                    // if (empty()) {
                                    //     # code...
                                    // }
                                    if (!empty($title) AND !empty($code) AND !empty($level)) {
                                        move_uploaded_file($tmp_material, "materials/$material");
                                        move_uploaded_file($tmp_dp, "assets/images/$dp");
                                        $sql = "insert into books(title, course_code, description, level, status, material, dp, created_at) values ('$title', '$code', '$desc', '$level', 'active', '$material', '$dp', NOW())";
                                        $run = mysqli_query($con, $sql);
                                        if ($run) {
                                            echo "<script> alert('uploaded')</script>";
                                            echo "<script> window.open('upload.php', '_self') </script>";
                                        }else{
                                            echo "<script> alert('upload failed')</script>";
                                        }
                                    }
                                }
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- *************************************************************** -->
                <!-- End Top Leader Table -->
                <!-- *************************************************************** -->
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- AJquery -->
    <!-- ============================================================== -->
    <script src="assets/libs/jquery/dist/jquery.min.js"></script>
    <script src="assets/libs/popper.js/dist/umd/popper.min.js"></script>
    <script src="assets/libs/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- apps -->
    <!-- apps -->
    <script src="dist/js/app-style-switcher.js"></script>
    <script src="dist/js/feather.min.js"></script>
    <script src="assets/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js"></script>
    <script src="dist/js/sidebarmenu.js"></script>
    <!--Custom JavaScript -->
    <script src="dist/js/custom.min.js"></script>
    <!--This page JavaScript -->
    <script src="assets/extra-libs/c3/d3.min.js"></script>
    <script src="assets/extra-libs/c3/c3.min.js"></script>
    <script src="assets/libs/chartist/dist/chartist.min.js"></script>
    <script src="assets/libs/chartist-plugin-tooltips/dist/chartist-plugin-tooltip.min.js"></script>
    <script src="assets/extra-libs/jvector/jquery-jvectormap-2.0.2.min.js"></script>
    <script src="assets/extra-libs/jvector/jquery-jvectormap-world-mill-en.js"></script>
    <script src="dist/js/pages/dashboards/dashboard1.min.js"></script>
</body>

</html>